#include<cmath>
#include<iostream>
#include<cstdlib>
#include<conio.h>
using namespace std;
#include<string>
#include<ctime>
long long ConvertToInt(string hexa);
string ConvertCharArrayToString(char* src);
int RandomNumber(int start, int end);
char ConvertToChar(int val);
string MakeKey();
int main()
{
	cout << "Press Y to generate a key" << endl;
	cout << "Press different key to exit" << endl;
	char c;
	c = _getch();
	if (toupper(c) == 'Y')
	{
		cout << MakeKey() << endl;
		system("pause");
	}
	else
	{
		exit(0);
	}
}

string MakeKey()
{
	string key = "";
	int number = RandomNumber(0x21, 0x7B);
	char hexa[129];
	_itoa(number, hexa, 16);
	for (int j = 0; j < 4; j++)
	{
		key += ConvertCharArrayToString(hexa);
	}
	long long num = ConvertToInt(key);
	key = to_string(num);
	key = key.substr(key.length() - 2, 2);
	key = "3" + key.substr(key.length() - 1, 1) + "3" + key.substr(key.length() - 2, 1);
	num = ConvertToInt(key);
	num = num + 0x1A1C;
	_itoa(num, hexa, 16);
	key = "";
	key += ConvertCharArrayToString(hexa);
	string temp = "";
	temp += ConvertToChar(ConvertToInt(key.substr(2, 2)) - 0x10);
	temp += ConvertToChar(ConvertToInt(key.substr(0, 2)) - 0xF);
	temp += ConvertToChar(number - 0xE);
	temp += ConvertToChar(number + 1 - 0xE);
	temp += ConvertToChar(number + 2 - 0xE);
	temp += ConvertToChar(number + 3 - 0xE);
	return temp;
}

int RandomNumber(int start, int end)
{
	srand(time(NULL));
	return start + rand() % (end - start + 1);
}

string ConvertCharArrayToString(char* src)
{
	string dest = "";
	for (int i = 0; i < strlen(src); i++)
	{
		dest += src[i];
	}
	return dest;
}

long long ConvertToInt(string hexa)
{
	long long sum = 0;
	int len = hexa.length();
	for (int i = 0; i < len; i++)
	{
		int temp = 0;
		if (hexa[i] >= '0' && hexa[i] <= '9')
		{
			temp = hexa[i] - 48;
		}
		else
		{
			if (hexa[i] == 'a') temp = 10;
			if (hexa[i] == 'b') temp = 11;
			if (hexa[i] == 'c') temp = 12;
			if (hexa[i] == 'd') temp = 13;
			if (hexa[i] == 'e') temp = 14;
			if (hexa[i] == 'f') temp = 15;
		}
		sum += temp * pow(16, len - 1 - i);
	}
	return sum;
}

char ConvertToChar(int val)
{
	return(char)val;
}