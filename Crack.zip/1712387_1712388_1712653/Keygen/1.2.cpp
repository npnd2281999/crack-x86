﻿#include<iostream>
using namespace std;
#include<string>
#include<cmath>
int ToNumber(string a);

int main()
{
	int  EBX, ECX;
	string EAX;
	cout << "Input Username (length <= 4): "; // khung chỉ điền tối đa 4 ký tự
	getline(cin, EAX);
	if (EAX.length() > 4)
	{
		cout << "Username too long" << endl;
		system("pause");
		exit(0);
	}
	EBX = ToNumber(EAX);
	if (EBX == -1)
	{
		cout << "Username contains only numbers." << endl;
		system("pause");
		exit(0);
	}
	else
	{
		ECX = EBX;				// ECX = ID
		ECX += 0X4C;			// ADD EBX,4C
		ECX += 1;				// INC EBX
		ECX += 0x38B;			// ADD EBX, 38B
		ECX += ECX;				// ADD EBX,EBX
		ECX *= 3;				// ADD EDX,3   IMUL EBX,EDX
		ECX -= 1;				// DEC EBX
		cout << "Your Serial is " << ECX << endl;
		system("pause");
	}
	return 0;
}

int ToNumber(string a) // Chuyển chuỗi thành số
{
	int sum = 0;
	int len = a.length();
	for (int i = 0; i < len; i++)
	{
		int temp = a[i] - 48;
		sum += temp * pow(10,(len - i - 1));
		if (a[i] < '0' || a[i] > '9')
		{
			return -1;
		}
	}
	return sum;
}