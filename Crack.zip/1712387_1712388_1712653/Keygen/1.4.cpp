﻿#define _CRT_SECURE_NO_WARNINGS

#include <iostream>
#include <cstdio>
#include <string.h>
#include <tchar.h>
#include <time.h>

#include <fstream>

using namespace std;

void main()
{
	char name[1024];
	char serial[9];
	memset(serial, 0, 9);

	srand((unsigned int)time(NULL));
	int random = rand() % 6 + 1;

	printf("Create register file\n");

	fstream f1("RES-REGGED.txt", ios::out);
	fstream f2("RES-VALIDATE.diz", ios::out);
	f2.close();
	f1 << random;
	f1.close();
	
	printf("Done!\n");

	printf("Enter name: ");
	gets_s(name);
	
	long len = strlen(name);
	long l = 0;

	_strrev(name);

	for (int i = 0; i < len; i++)
	{
		l -= name[i] - 0x20;
	}

	sprintf(serial, "%8X", l);

	_strrev(serial);

	printf("Serial: %s", serial);

	char done = 0;

	while (!done)
	{
		scanf("%c", &done);
	}

	remove("RES-REGGED.txt");
	remove("RES-VALIDATE.diz");

}